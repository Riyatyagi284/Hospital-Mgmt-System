// "use client";

// import { useState } from "react";
// import Link from "next/link";
// import { Search, SlidersHorizontal, Plus, Eye, Pencil, Trash2 } from "lucide-react";
// import { usePatientStats } from '@/hooks/usePatients';
// import PageContainer from "@/components/shared/PageContainer";
// import StatCard from "@/components/shared/StatCard";
// import StatusBadge from "@/components/shared/StatusBadge";
// import { patients } from "@/data/mockData";

// // import { usePatients, useDeletePatient } from '@/hooks/usePatients';
// // import { usePatientStore } from '@/store/patient.store';
// // import { Patient } from '@/types/api.types';


// export default function Patients() {
//   const [search, setSearch] = useState("");

//   const { data: statsData, isLoading, error } = usePatientStats();

//   console.log("Component Rendered");
//   console.log("stats data", statsData);
//   console.log("isLoading", isLoading);
//   console.log("error", error);

//   const stats = [
//     {
//       title: 'Total Patients',
//       value: statsData?.totalPatients || 0,
//       change: statsData?.percentageChange.total || 0,
//       changeType: 'increase',
//     },
//     {
//       title: 'New Patients (This Month)',
//       value: statsData?.newPatientsThisMonth || 0,
//       change: statsData?.percentageChange.new || 0,
//       changeType: 'increase',
//     },
//     {
//       title: 'Active Patients',
//       value: statsData?.activePatients || 0,
//       change: statsData?.percentageChange.active || 0,
//       changeType: 'increase',
//     },
//     {
//       title: 'Inactive Patients',
//       value: statsData?.inactivePatients || 0,
//       change: statsData?.percentageChange.inactive || 0,
//       changeType: 'decrease',
//     },
//   ];

//   const filtered = patients.filter((p) =>
//     p.name.toLowerCase().includes(search.toLowerCase())
//   );

//   return (
//     <PageContainer title="Patients">

//       {/*  */}

//       {isLoading ? (
//         <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-4">
//           {[1, 2, 3, 4].map((i) => (
//             <div
//               key={i}
//               className="rounded-xl border border-border bg-card p-5 shadow-sm animate-pulse"
//             >
//               <div className="h-5 w-24 rounded bg-muted mb-4"></div>

//               <div className="h-8 w-16 rounded bg-muted"></div>
//             </div>
//           ))}
//         </div>
//       ) : error ? (

//         /* ========================= */
//         /* ERROR */
//         /* ========================= */

//         <div className="rounded-lg border border-red-200 bg-red-50 p-4 text-red-700">
//           Failed to load patient statistics
//         </div>

//       ) : (

//         /* ========================= */
//         /* STATS */
//         /* ========================= */

//         <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-4">
//           {stats.map((s) => (
//             <StatCard
//               key={s.title}
//               {...s}
//             />
//           ))}
//         </div>
//       )}

//       {/* Search/Filter Area */}

//       <div className="mt-6 rounded-xl border border-border bg-card p-6 shadow-sm">
//         <div className="mb-5 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
//           <h3 className="text-lg font-semibold text-foreground">All Patients</h3>
//           <div className="flex items-center gap-3">
//             <div className="flex items-center gap-2 rounded-lg border border-border bg-background px-3 py-2">
//               <Search className="h-4 w-4 text-muted-foreground" />
//               <input
//                 type="text"
//                 placeholder="Search patients..."
//                 value={search}
//                 onChange={(e) => setSearch(e.target.value)}
//                 className="bg-transparent text-sm outline-none placeholder:text-muted-foreground"
//               />
//             </div>
//             <button className="flex items-center gap-2 rounded-lg border border-border px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-muted">
//               <SlidersHorizontal className="h-4 w-4" /> Filters
//             </button>
//             <Link
//               href="/patients/add"
//               className="flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
//             >
//               <Plus className="h-4 w-4" /> Add Patient
//             </Link>
//           </div>
//         </div>

//         {/* Table */}
//         <div className="overflow-x-auto">
//           <table className="w-full text-sm">
//             <thead>
//               <tr className="border-b border-border text-left text-muted-foreground">
//                 <th className="pb-3 font-medium">#</th>
//                 <th className="pb-3 font-medium">Patient Name</th>
//                 <th className="pb-3 font-medium">Gender</th>
//                 <th className="pb-3 font-medium">Age</th>
//                 <th className="pb-3 font-medium">Phone</th>
//                 <th className="pb-3 font-medium">Email</th>
//                 <th className="pb-3 font-medium">Last Visit</th>
//                 <th className="pb-3 font-medium">Status</th>
//                 <th className="pb-3 font-medium">Actions</th>
//               </tr>
//             </thead>
//             <tbody>
//               {filtered.map((p, i) => (
//                 <tr key={p.id} className="border-b border-border last:border-0 hover:bg-muted/30 transition-colors">
//                   <td className="py-3 text-muted-foreground">{i + 1}</td>
//                   <td className="py-3">
//                     <div className="flex items-center gap-3">
//                       <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary/10 text-xs font-semibold text-primary">
//                         {p.name.split(" ").map((n) => n[0]).join("")}
//                       </div>
//                       <div>
//                         <p className="font-medium text-foreground">{p.name}</p>
//                         <p className="text-xs text-muted-foreground">PID: {p.pid}</p>
//                       </div>
//                     </div>
//                   </td>
//                   <td className="py-3 text-muted-foreground">{p.gender}</td>
//                   <td className="py-3 text-muted-foreground">{p.age}</td>
//                   <td className="py-3 text-muted-foreground">{p.phone}</td>
//                   <td className="py-3 text-muted-foreground">{p.email}</td>
//                   <td className="py-3 text-muted-foreground">{p.lastVisit}</td>
//                   <td className="py-3"><StatusBadge status={p.status} /></td>
//                   <td className="py-3">
//                     <div className="flex items-center gap-1">
//                       <button className="rounded-lg p-1.5 text-muted-foreground transition-colors hover:bg-muted hover:text-primary"><Eye className="h-4 w-4" /></button>
//                       <button className="rounded-lg p-1.5 text-muted-foreground transition-colors hover:bg-muted hover:text-primary"><Pencil className="h-4 w-4" /></button>
//                       <button className="rounded-lg p-1.5 text-muted-foreground transition-colors hover:bg-muted hover:text-destructive"><Trash2 className="h-4 w-4" /></button>
//                     </div>
//                   </td>
//                 </tr>
//               ))}
//             </tbody>
//           </table>
//         </div>

//         {/* Pagination */}
//         <div className="mt-5 flex items-center justify-between text-sm text-muted-foreground">
//           <span>Showing 1 to 8 of 1,245 results</span>
//           <div className="flex items-center gap-1">
//             <button className="rounded-lg px-3 py-1.5 transition-colors hover:bg-muted">&lt;</button>
//             <button className="rounded-lg bg-primary px-3 py-1.5 text-primary-foreground">1</button>
//             <button className="rounded-lg px-3 py-1.5 transition-colors hover:bg-muted">2</button>
//             <button className="rounded-lg px-3 py-1.5 transition-colors hover:bg-muted">3</button>
//             <span>...</span>
//             <button className="rounded-lg px-3 py-1.5 transition-colors hover:bg-muted">156</button>
//             <button className="rounded-lg px-3 py-1.5 transition-colors hover:bg-muted">&gt;</button>
//           </div>
//         </div>
//       </div>
//     </PageContainer>
//   );
// }




// 

"use client";

import { useState } from "react";

import PageContainer from "@/components/shared/PageContainer";

import PatientsStats from "@/components/Shared/patients/PatientsStats";
import PatientsToolbar from "@/components/Shared/patients/PatientsToolbar";
import PatientsTable from "@/components/Shared/patients/PatientsTable";

export default function Patients() {
  const [search, setSearch] = useState("");

  // const filteredPatients = patients.filter((p) =>
  //   p.name.toLowerCase().includes(search.toLowerCase())
  // );

  return (
    <PageContainer title="Patients">

      {/* STATS */}
      <PatientsStats />

      {/* TABLE SECTION */}
      <div className="mt-6 rounded-xl border border-border bg-card p-6 shadow-sm">

        {/* TOOLBAR */}
        <PatientsToolbar
          search={search}
          setSearch={setSearch}
        />

        {/* TABLE */}
        {/* <PatientsTable patients={filteredPatients} /> */}
        <PatientsTable  />

      </div>
    </PageContainer>
  );
}